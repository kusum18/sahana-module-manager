insert into test_demo values('v1-1');
insert into test_demo values('v1-2');
insert into test_demo values('v1-3');
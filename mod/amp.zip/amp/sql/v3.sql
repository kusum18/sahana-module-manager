insert into test_demo values(Null,"v3");
insert into test_demo values(Null,"v3");
insert into test_demo values(Null,"v3");
insert into test_demo values(Null,"v3");
insert into test_demo values(Null,"v3");
insert into test_demo values(Null,"v3");
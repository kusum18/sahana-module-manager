insert into test_demo values('v2.1.2-1');
insert into test_demo values('v2.1.2-2');
insert into test_demo values('v2.1.2-3');
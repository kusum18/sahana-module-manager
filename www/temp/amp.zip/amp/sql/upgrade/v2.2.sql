insert into test_demo values('v2.2-1');
insert into test_demo values('v2.2-2');
insert into test_demo values('v2.2-3');
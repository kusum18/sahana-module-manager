onload=update();
function update(){
setTimeout('update();',100000);
xajax__shn_cap_update_alerts();
}
insert into test_demo values('v2.2.4-1');
insert into test_demo values('v2.2.4-2');
insert into test_demo values('v2.2.4-3');
insert into test_demo values(Null,"v2.5.5");
insert into test_demo values(Null,"v2.5.5");
insert into test_demo values(Null,"v2.5.5");
insert into test_demo values(Null,"v2.5.5");
insert into test_demo values(Null,"v2.5.5");
insert into test_demo values(Null,"v2.5.5");
insert into test_demo values('v2.2.5-1');
insert into test_demo values('v2.2.5-2');
insert into test_demo values('v2.2.5-3');